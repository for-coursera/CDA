function(d,range) {
  vec <- as.data.frame(c(range))
  colnames(vec) <-c("id")
  filenames <- list.files(paste(getwd(),d, sep = "/"), pattern="*.csv", full.names=TRUE)
  j <- 0
  l <-0
  data<-data.frame(id=0, nobs=0)
  for (i in filenames) {
    j = j+1
    data[j,1] <- j
    data[j,2] <- as.integer(nrow(omit<-na.omit(read.csv(i))))
  }
  log<-data$id %in% vec$id
  res<-data[data$id[log],]
  rownames(res)<-NULL
  return(res)
}