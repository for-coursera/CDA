function (n,d,s=FALSE)
{
  n<-as.integer(n)
  if (n < 10) {
    n <- paste("00",n,sep="")
  } else {
    if (n < 100) {
      n <- paste("0",n,sep="")
    }
  }
  if (s==TRUE) {
      print(summary(read.csv(paste(getwd(),d,sprintf("%s.csv",n), sep = "/"))))
  }
  read.csv(paste(getwd(),d,sprintf("%s.csv",n), sep = "/"))
}