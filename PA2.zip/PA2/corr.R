function (d, thresh = 0) {
  k <- 0
  lis <- list()
  data <- c()
  filenames <- list.files(paste(getwd(),d, sep = "/"), pattern="*.csv", full.names=TRUE)
  for (i in filenames) {
    omit <- nrow(na.omit(read.csv(i)))
    if (omit > thresh) {
      lis[[i]]<-as.data.frame(read.csv(i))
    }
  }
  for (j in lis) {
    k <- k+1
    tab<-na.omit(as.data.frame(j))
    data[k] <- cor(as.numeric(tab$sulfate),as.numeric(tab$nitrate))
  }
data
}