rankall <- function (o, r = "best") {
  # set values
  k <- 0
  thestate<-c()
  thestateRanked<-c()
  result<-data.frame(hospital=0,state=0)
  t<-read.csv("outcome-of-care-measures.csv", colClasses="character")
  t[t=="Not Available"] <- NA
  states<-unique(t$State)
  outcomes<-c("heart attack", "heart failure","pneumonia")
  # check outcome
  if ((o %in% outcomes)==F) {
    stop("invalid outcome")
  }
  # proceed with calculations
  
  for (i in states){
    k<-k+1
    thestate<-(subset(t, State==i))
    if (o=="heart attack") {
      if (r!="worst") {
        if (r=="best") {
          thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,11]), thestate[,2])), ]
          result[k,1] <- thestateRanked[1,2]
          result[k,2] <- i
        } else {
          r<-as.numeric(r)
          thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,11]), thestate[,2])), ]
          result[k,1] <- thestateRanked[r,2]
          result[k,2] <- i
        }
      } else {
        thestateRanked<-thestate[with(thestate,order(as.numeric(thestate$Hospital.30.Day.Death..Mortality..Rates.from.Heart.Attack), thestate$Hospital.Name)), ]
        thestateRankedNA<-subset(thestateRanked, !is.na(Hospital.30.Day.Death..Mortality..Rates.from.Heart.Attack))
        rr<-nrow(thestateRankedNA)
        result[k,1] <- thestateRankedNA[rr,2]
        result[k,2] <- i
      }
    } else {
      if (o=="heart failure") {
        if (r!="worst") {
          if (r=="best") {
            thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,17]), thestate[,2])), ]
            result[k,1] <- thestateRanked[1,2]
            result[k,2] <- i
          } else {
            r<-as.numeric(r)          
            thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,17]), thestate[,2])), ]
            result[k,1] <- thestateRanked[r,2]
            result[k,2] <- i
          }
        } else {
          thestateRanked<-thestate[with(thestate,order(as.numeric(thestate$Hospital.30.Day.Death..Mortality..Rates.from.Heart.Failure), thestate$Hospital.Name)), ]
          thestateRankedNA<-subset(thestateRanked, !is.na(Hospital.30.Day.Death..Mortality..Rates.from.Heart.Failure))
          rr<-nrow(thestateRankedNA)
          result[k,1] <- thestateRankedNA[rr,2]
          result[k,2] <- i
        }
      } else {
        if (r!="worst") {
          if (r=="best") {
            thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,23]), thestate[,2])), ]
            result[k,1] <- thestateRanked[1,2]
            result[k,2] <- i
          } else {
            r<-as.numeric(r)          
            thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,23]), thestate[,2])), ]
            result[k,1] <- thestateRanked[r,2]
            result[k,2] <- i
          }
        } else {
          thestateRanked<-thestate[with(thestate,order(as.numeric(thestate$Hospital.30.Day.Death..Mortality..Rates.from.Pneumonia), thestate$Hospital.Name)), ]
          thestateRankedNA<-subset(thestateRanked, !is.na(Hospital.30.Day.Death..Mortality..Rates.from.Pneumonia))
          rr<-nrow(thestateRankedNA)
          result[k,1] <- thestateRankedNA[rr,2]
          result[k,2] <- i
        } 
      }
    }
  }
  result[with(result,order(state)), ]
}