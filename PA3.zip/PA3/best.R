best <- function (s, o) {
thestate<-c()
thestateRanked<-c()
t<-read.csv("outcome-of-care-measures.csv", colClasses="character")
t[t=="Not Available"] <- NA
states<-unique(t$State)
if ((s %in% states)==F) {
  stop("invalid state")
}
outcomes<-c("heart attack", "heart failure","pneumonia")
if ((o %in% outcomes)==F) {
  stop("invalid outcome")
}
if (o=="heart attack") {
  thestate<-(subset(t, State==s))
  thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,11]))), ]
  print(thestateRanked[1,2])
  
} else {
  if (o=="heart failure") {
    thestate<-(subset(t, State==s))
    thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,17]))), ]
    print(thestateRanked[1,2])
  } else {
    thestate<-(subset(t, State==s))
    thestateRanked<-thestate[with(thestate,order(as.numeric(thestate[,23]))), ]
    print(thestateRanked[1,2])
  }
}
}