agecount <- function (a) {
  hmcd<-readLines("homicides.txt")
  agecount<-length(grep(paste(a,"years old"),hmcd))
  print(agecount)
}