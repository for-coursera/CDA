count <- function (r="shooting") {
  hmcd<-readLines("homicides.txt")
  count<-0
  if (r=="shooting") {
    count<-length(grep("[Cc]ause: [Ss]hooting",hmcd))
  } else {
    if (r=="asphyxiation") {
      count<-length(grep("[Cc]ause: [Aa]sphyxiation",hmcd))
    } else {
      if (r=="blunt force") {
        count<-length(grep("[Cc]ause: [B]lunt [Ff]orce",hmcd))
      } else {
        if (r=="other") {
          count<-length(grep("[Cc]ause: [Oo]ther",hmcd))
        } else {
          if (r=="stabbing") {
            count<-length(grep("[Cc]ause: [Ss]tabbing",hmcd))
          } else {
            count<-length(grep("[Cc]ause: [Uu]nknown",hmcd))
          }
        }
      }
    }
  }
  print(count)
}